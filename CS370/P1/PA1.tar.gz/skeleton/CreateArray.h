extern float get_running_ratio();
