#include <stem.h>
#include <gtest/gtest.h>

TEST(portAlg, step1)
{
	Stem ss;
	EXPECT_EQ("abc", ss.step1("abc"));
	EXPECT_EQ("def", ss.step1("\'def"));
}

TEST(portAlg, step2)
{
	Stem ss;
	string t = "abcsses";
	ss.step2(t);
	EXPECT_EQ("abcss", t);
}

int main(int argc, char* argv[])
{
	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
