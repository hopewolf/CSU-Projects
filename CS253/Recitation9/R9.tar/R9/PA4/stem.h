#pragma once
#include <iostream>
#include <string>
using namespace std;

class Stem{
public:
    bool isVowel(const char &);
	string step1(string);
	void step2(string&);
    void step3(string&);
};
